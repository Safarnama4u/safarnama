# Safarnama

Discover India, One Journey at a Time.

This is the initial Safarnama travel and nature website foundation.

## Files
- `index.html` — homepage structure
- `style.css` — responsive design
- `script.js` — small interactive features
- `assets/logo.png` — Safarnama logo

## Next development
Destination pages, real destination search, travel-guide content, legal pages, SEO, and GitHub Pages deployment can be added without replacing the whole foundation.
